package com.example.ex1;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.util.ArrayList;
import android.support.design.widget.Snackbar;


public class MainActivity extends AppCompatActivity{

    public static final String TO_PRESENT = "to_present";
    final String LIST_STATE_KEY = "list_state_key";
    final String SAVE_TEXT_EDIT_TEXT = "save_text_edit_text";
    private static LinearLayoutManager linearLayoutManager;
    private Parcelable mListState = null;
    private RecyclerUtils.RecyclerViewAdapter adapter = new RecyclerUtils.RecyclerViewAdapter();
    private ArrayList<Recycler_item> mToPresent =new ArrayList<>(Recycler_item.getAll());
    private EditText edittext;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //use on Create and save instance state
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.my_recycler_view);
        linearLayoutManager = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setAdapter(adapter);

        Button button = (Button) findViewById(R.id.sendButton);
        edittext = (EditText) findViewById(R.id.textToSend);

        if (savedInstanceState!= null){
            onRestoreInstanceState(savedInstanceState);
        }

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newText = edittext.getText().toString();
                if(newText.equals("")){
                    String message = "Error! can't send empty message";
                    int duration = Snackbar.LENGTH_SHORT;
                    showSnackbar(v, message, duration);
                }
                else {
                    ArrayList<Recycler_item> copymToPresent =new ArrayList<>(mToPresent);
                    Recycler_item new_recycler =new Recycler_item(newText);
                    copymToPresent.add(new_recycler);
                    mToPresent = copymToPresent;
                    adapter.submitList(mToPresent);
                    edittext.getText().clear();
                }
            }
        });

    }

    public void showSnackbar(View view, String message,int duration ){
        Snackbar.make(view,message,duration).show();
    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState){
        super.onRestoreInstanceState(savedInstanceState);
        if(savedInstanceState != null){
            adapter.submitList(mToPresent);
            mListState = savedInstanceState.getParcelable(LIST_STATE_KEY);
            linearLayoutManager.onRestoreInstanceState(mListState);
            mToPresent = (ArrayList<Recycler_item>) savedInstanceState.getSerializable(TO_PRESENT);
            edittext.setText(savedInstanceState.get(SAVE_TEXT_EDIT_TEXT).toString());

        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState){
        super.onSaveInstanceState(outState);
        mListState = linearLayoutManager.onSaveInstanceState();
        outState.putParcelable(LIST_STATE_KEY,mListState);
        outState.putSerializable(TO_PRESENT,mToPresent);
        outState.putString(SAVE_TEXT_EDIT_TEXT,edittext.getText().toString());


    }

}
