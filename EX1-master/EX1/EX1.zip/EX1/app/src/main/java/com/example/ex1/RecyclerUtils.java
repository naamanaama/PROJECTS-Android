package com.example.ex1;
import android.support.annotation.NonNull;
import android.support.v7.recyclerview.extensions.ListAdapter;
import android.support.v7.util.DiffUtil;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * A collection of static classes - Holder, Adapter and Diff Callback
 */
public class RecyclerUtils {

    /**
     * one RecyclerHolder holds one view template
     */
    static class RecyclerHolder extends RecyclerView.ViewHolder{
        TextView textView;
        RecyclerHolder(@NonNull View itemView){
            super(itemView);
            textView = itemView.findViewById(R.id.text_to_show);
        }
    }

    /**
     * providing calculations for insertions / deletions of items
     * DiffUtil is a utility class that can calculate the difference
     * between two lists and output a list of update operations that
     * converts the first list into the second one
     */
    static class RecyclerCallback extends DiffUtil.ItemCallback<Recycler_item>{
        @Override
        public boolean areItemsTheSame(@NonNull Recycler_item r1, @NonNull Recycler_item r2){
            return r1.text.equals(r2.text);
        }
        @Override
        public boolean areContentsTheSame(@NonNull Recycler_item r1, @NonNull Recycler_item r2){
            return  r1.equals(r2);
        }
    }


    /**
     * Customize each view template, can see the actual data
     */
    static class RecyclerViewAdapter extends ListAdapter<Recycler_item,RecyclerHolder>{

        RecyclerViewAdapter( ){
            super(new RecyclerCallback());
        }

        //Create new views (invoked by the layout manager)
        @NonNull
        @Override
        public RecyclerHolder onCreateViewHolder(@NonNull ViewGroup parent, int itemType){

            View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_one_recycle, parent,false);
            RecyclerHolder holder = new RecyclerHolder(itemView);
            return holder;
        }

        //Replace the contents of a view (invoked by the layout manager)
        @Override
        public void onBindViewHolder(@NonNull RecyclerHolder recyclerHolder, int position){
            Recycler_item recycler_item = getItem(position);
            recyclerHolder.textView.setText(recycler_item.text);
        }

    }


}
