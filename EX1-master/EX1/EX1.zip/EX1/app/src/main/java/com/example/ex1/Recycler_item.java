package com.example.ex1;
import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;

/**
 * This class represents a single Recycler item- in our case it is a text view
 * */

public class Recycler_item implements Serializable {
    /**
     * Static method that returns all current recycler items that were created
     * @return - list of all current Recyclers
     */
    static List<Recycler_item> getAll(){
        ArrayList<Recycler_item> all =new ArrayList<>();
        return all;
    }

    public String text;

    /**
     * Constructor
     * @param text_to_present - the text we want to present when creating this recycler item
     */
    public Recycler_item(String text_to_present){
        this.text = text_to_present;

    }

    @Override
    public boolean equals(Object o){
        return this ==o;
    }



}


